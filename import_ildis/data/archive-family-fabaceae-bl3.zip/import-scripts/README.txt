=================================================================
====               SQLite import scripts                      ====
====               for Catalogue of Life                     ====
====           Darwin Core Archive Downloads                 ====
=================================================================

Author: Ruud Altenburg
Copyright: ETI BioInformatics
Developed in: i4Life project Work Package 4
Version 1.0, 2012



Synopsis
=================================================================
These import scripts can be used to import the downloaded archive into a database. Please refer to the
documentation for each database for detailed instructions.